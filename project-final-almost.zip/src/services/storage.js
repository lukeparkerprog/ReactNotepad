export const keys = {
    notes: 'notes',
    activeItem: 'activeItem',
    reloadNeeded: 'reloadNeeded'
}


export const getSessionItem = function (key) {
    let item = sessionStorage.getItem(key);
    item = JSON.parse(item);
    return item;
}

export const setSessionItem = function (key, value) {
    let item = JSON.stringify(value);
    sessionStorage.setItem(key, item);
}

export const removeSessionItem = function (key) {
    sessionStorage.removeItem(key);
}
