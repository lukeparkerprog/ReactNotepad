import React, { Component } from 'react';

class AddNote extends Component {
    constructor(props) {
        super(props);

        this.state = {
            title:'',
            content: ''
        }
    }

    onTitleChange(event) {
        this.setState({
            title: event.target.value
        })
    }

    onContentChange(event) {
        this.setState({
            content: event.target.value
        })
    }

    onSubmit() {
        this.props.onAdd(this.state.title, this.state.content)
        this.props.goHome();
    }

    render() {
        return (
            <div className="AddNote">
                <h3>Add Note</h3>
                    <div className="NoteField">
                        <input
                            id="title"
                            value={this.state.title}
                            onChange={this.onTitleChange.bind(this)}
                            placeholder="Title"
                            required
                        />
                    </div>
                    <div className="NoteField">
                        <textarea
                            id="content"
                            value={this.state.content}
                            onChange={this.onContentChange.bind(this)}
                            placeholder="Content"
                            form="addNoteForm"
                        />
                </div>
                <div className="NoteButton">
                    <button onClick={this.onSubmit.bind(this)}>Save Note</button>
                    <button onClick={this.props.goHome.bind(this)}>Cancel</button>
                </div>
            </div>
        );
    }
}

export default AddNote;
